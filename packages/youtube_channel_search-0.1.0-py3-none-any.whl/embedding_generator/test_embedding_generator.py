import datetime
from embedding_generator import EmbeddingGenerator

metadata_chunks = {'publish_date': datetime.datetime(2015, 11, 8, 0, 0), 'author': 'One Minute Economics', 'channel_id': 'UCpsroJwsVKQvRH3ZqdvRetQ', 'channel_url': 'https://www.youtube.com/channel/UCpsroJwsVKQvRH3ZqdvRetQ', 'thumbnail_url': 'https://i.ytimg.com/vi/beAvFHP4wDI/sddefault.jpg', 'title': 'Inflation Explained in One Minute', 'video_id': 'beAvFHP4wDI', 'text_chunks': [{'start_time': '00:00:00', 'text': " Let's assume your monthly income were to somehow double.  Congratulations.  You can now, for the most part, afford to buy two times more stuff.  But what if the monthly income of everyone else were to also double?  Well, in that case, you'd no longer be able to buy two times more stuff, because since  everyone else also earns two times more, there would be two times more money chasing roughly  the same number of goods.  Let's take things one step further.  What if your income doubles, but the income of everyone else triples?  In that case, you'd actually become poorer.  Why?  Because making two times more money is not enough to keep up with everyone else, who now  makes three times more.  If there's an overall increase in the price of goods and services of X% this year, you  have to earn at least X% more than last year to avoid becoming poorer in real terms.  History makes the effects of inflation crystal clear.  Today, each dollar buys you approximately 39 times less potatoes than 100 years ago,"}, {'start_time': '00:00:48', 'text': ' History makes the effects of inflation crystal clear.  Today, each dollar buys you approximately 39 times less potatoes than 100 years ago,  or 20 times less coffee, 24 times less bread, and so on.'}]}
embedding_generator = EmbeddingGenerator()

embedding_generator.generate_embeddings(metadata_chunks)


db = embedding_generator.load_db()
print(dir(db))