
import chromadb
import numpy as np
from openai import OpenAI
class EmbeddingGenerator:
    def __init__(self, model_name="text-embedding-3-large", collection_name="video_data_medium", embedding_size = 3072):
        self.embedding_client = OpenAI()
        self.model_name = model_name
        self.db_client = chromadb.PersistentClient()
        self.collection_name = collection_name
        self.embedding_size = embedding_size
        # self.db_client.list_collections()
        self.collection = self.db_client.get_or_create_collection(collection_name)

    def generate_embeddings(self, metadata_chunk):
            video_metadata = {
                'publish_date': str(metadata_chunk['publish_date']),
                'author': metadata_chunk['author'],
                'channel_id': metadata_chunk['channel_id'],
                'channel_url': metadata_chunk['channel_url'],
                'thumbnail_url': metadata_chunk['thumbnail_url'],
                'title': metadata_chunk['title'],
                'video_id': metadata_chunk['video_id']
            }
            text_chunks = metadata_chunk['text_chunks']
            for chunk in text_chunks:
                text = chunk['text']
                if text is None:
                     continue
                start_time = chunk['start_time']
                unique_id = f"{video_metadata['video_id']}_{start_time}"
                # Generate embedding for the text chunk
                try:
                    embedding = self.generate_embedding(text)
                except Exception as e:
                     print(f"Failed with error {e}. Text is '{text}'")
                     
                # Add the video metadata and text chunk to the collection
                try:
                    self.collection.add(
                        documents=[text],
                        embeddings=[embedding],
                        metadatas=[{
                            **video_metadata,
                            'start_time': start_time
                        }],
                        ids = [unique_id]
                    )
                except Exception as e:
                     print(f"Failed with error {e}")


    def normalize_l2(self, x):
        x = np.array(x)
        if x.ndim == 1:
            norm = np.linalg.norm(x)
            if norm == 0:
                return x
            return x / norm
        else:
            norm = np.linalg.norm(x, 2, axis=1, keepdims=True)
            return np.where(norm == 0, x, x / norm)

    def generate_embedding(self, text):
        response = self.embedding_client.embeddings.create(model="text-embedding-3-large", input=[text])
        cut_embedding = response.data[0].embedding[:self.embedding_size]
        norm_embedding = self.normalize_l2(cut_embedding)
        return norm_embedding.tolist()
    


    def load_db(self):
         return self.db_client.get_collection("video_data")