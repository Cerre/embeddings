import math

class TextChunker:
    def __init__(self, chunk_size=60, overlap=0.2):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk_texts(self, input_data, video):
        chunks = []  # List to hold the final chunks
        current_chunk = []  # Current chunk being built
        next_chunk = []  # Next chunk starts when overlap starts
        current_chunk_start_time = input_data[0]['start']  # Initialize start time of the current chunk
        overlap_start = self.chunk_size * (1 - self.overlap)  # Calculate when to start appending to next chunk

        for segment in input_data:
            segment_start_relative = segment['start'] - current_chunk_start_time
            # Add segment to the current chunk if within the chunk size
            if segment_start_relative < self.chunk_size:
                current_chunk.append(segment['text'])
                # Start appending to next chunk as well once overlap_start is reached
                if segment_start_relative >= overlap_start:
                    next_chunk.append(segment['text'])
            # If the current segment's start time exceeds the chunk size, it's time to finalize the current chunk
            if segment_start_relative >= self.chunk_size:
                # Combine the texts for the current chunk and add it to the chunks list
                chunks.append({"start_time": self._format_time(current_chunk_start_time), "text": " ".join(current_chunk)})
                # The next chunk becomes the current chunk
                current_chunk = next_chunk
                next_chunk = []
                # Update the start time for the new current chunk
                current_chunk_start_time = current_chunk_start_time + overlap_start
                overlap_start = self.chunk_size * (1 - self.overlap)  # Recalculate overlap start for the new chunk

        # After going through all segments, add any remaining texts to the last chunk
        # breakpoint()
        if current_chunk:
            # breakpoint()
            if segment["text"] == current_chunk[-1]:
                final_text = "".join(current_chunk)
            elif next_chunk:
                breakpoint()
                pass
            else:
                final_text = "".join(current_chunk + [segment["text"]])  # Include next_chunk to not lose text in the overlap
                
            chunks.append({"start_time": self._format_time(current_chunk_start_time), "text": final_text})
        return {
            'publish_date': video.publish_date,
            'author': video.author,
            'channel_id': video.channel_id,
            'channel_url': video.channel_url,
            'thumbnail_url': video.thumbnail_url,
            'title': video.title,
            'video_id': video.video_id,
            'text_chunks': chunks
        }
    
    def _format_time(self, seconds):
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        seconds = int(seconds % 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"