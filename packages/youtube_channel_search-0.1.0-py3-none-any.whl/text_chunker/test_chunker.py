from text_chunker import TextChunker

metadata_dicts = [{'start': 0.0, 'end': 4.32, 'text': " This is Trevor Milton, he's a tech bro who told everyone that he built a fully functional", 'avg_logprob': -0.14}, {'start': 4.32, 'end': 8.56, 'text': ' electric semi truck that would change the world. He took his company Nikola public with a', 'avg_logprob': -0.14}, {'start': 8.56, 'end': 13.2, 'text': ' SPAC and got super rich overnight. The only problem is that that fully functional electric truck', 'avg_logprob': -0.14}, {'start': 13.2, 'end': 17.52, 'text': " would be better described as an inoperable pile of garbage. And now he's spending four years in", 'avg_logprob': -0.14}, {'start': 17.52, 'end': 22.0, 'text': " federal prison for a line to investors. It's a prime example of when fake it till you make it", 'avg_logprob': -0.14}, {'start': 22.0, 'end': 26.08, 'text': " goes wrong. And in today's video, we'll look at seven other tech bros who had to do hard time.", 'avg_logprob': -0.14}, {'start': 26.08, 'end': 29.68, 'text': ' So hopefully you can learn something and not get caught by the law with your own shady', 'avg_logprob': -0.14}, {'start': 29.68, 'end': 35.2, 'text': " business ideas. It is March 29, 2024 and you're watching the code record. A little over a year ago,", 'avg_logprob': -0.15}, {'start': 35.2, 'end': 39.68, 'text': ' this guy was one of the richest people in the world with an 11 figure net worth. But just a few days', 'avg_logprob': -0.15}, {'start': 39.68, 'end': 45.76, 'text': " ago, Sam Bankman freed was sentenced to 25 years in federal prison. Bankman's crypto bank FTX", 'avg_logprob': -0.15}, {'start': 45.76, 'end': 50.96, 'text': ' lent billions of dollars in customer funds to Alameda Research, a trading firm founded by himself.', 'avg_logprob': -0.15}, {'start': 50.96, 'end': 55.52, 'text': " When crypto went down in 2022, those trades didn't do too well. And the entire house of cards", 'avg_logprob': -0.15}, {'start': 55.52, 'end': 62.8, 'text': ' collapsed. FTX got so big in part because of its aggressive marketing that had promoters like Tom', 'avg_logprob': -0.12}, {'start': 62.8, 'end': 67.52, 'text': ' Brady, Steph Curry, and a whole bunch of YouTubers. But the bigger the scam, the harder it falls.', 'avg_logprob': -0.12}, {'start': 67.52, 'end': 72.0, 'text': ' Despite making major political donations, also in violation of the law, the totally honest and', 'avg_logprob': -0.12}, {'start': 72.0, 'end': 76.56, 'text': ' not corrupt politicians decided it was best to let Bankman fry. While most tech bros tend to be', 'avg_logprob': -0.12}, {'start': 76.56, 'end': 80.72, 'text': " men, it's also true that most prisoners are men as well. But there are courageous women in tech", 'avg_logprob': -0.12}, {'start': 80.72, 'end': 85.2, 'text': ' breaking the glass ceiling and also breaking bad. Elizabeth Holmes was once called the next', 'avg_logprob': -0.12}, {'start': 85.2, 'end': 89.84, 'text': ' Steve Jobs, Andrew Company Theranos put her in the Forbes 400. They produced a revolutionary', 'avg_logprob': -0.12}, {'start': 89.84, 'end': 94.4, 'text': ' blood testing product that could run medical diagnostics with just a few drops of blood without', 'avg_logprob': -0.12}, {'start': 94.4, 'end': 98.56, 'text': ' the need to take a full blood sample. Investors poured tons of money into this amazing product,', 'avg_logprob': -0.12}, {'start': 98.56, 'end': 101.76, 'text': " but the only problem is the product didn't actually work like she said it did.", 'avg_logprob': -0.12}, {'start': 102.56, 'end': 107.28, 'text': ' When people found out, the company collapsed, and eventually she was sentenced to 11 years in prison,', 'avg_logprob': -0.12}, {'start': 107.28, 'end': 111.2, 'text': ' which was later reduced to nine years. Defrauding investors is one way to go to prison,', 'avg_logprob': -0.12}, {'start': 111.2, 'end': 115.68, 'text': " but it's not the only way. Anthony Lewandowski is a brilliant engineer who co-founded Google's", 'avg_logprob': -0.12}, {'start': 115.68, 'end': 120.24, 'text': " self-driving car program, Waymo, which gave him access to some of Google's highly protected trade", 'avg_logprob': -0.12}, {'start': 120.24, 'end': 124.4, 'text': ' secrets. He went on to form a self-driving truck company called Otto, which was later acquired by', 'avg_logprob': -0.12}, {'start': 124.4, 'end': 130.16, 'text': " Uber for 680 million. Before leaving Google, Lewandowski downloaded a bunch of Waymo's confidential", 'avg_logprob': -0.12}, {'start': 130.16, 'end': 135.04, 'text': " files, which included things like blueprints and hardware schematics. Later, one of Waymo's suppliers", 'avg_logprob': -0.12}, {'start': 135.04, 'end': 140.08, 'text': " was accidentally copied on an email that showed how Uber was copying Waymo's LiDAR design. Google sued", 'avg_logprob': -0.13}, {'start': 140.08, 'end': 144.8, 'text': ' Uber, but the Department of Justice also filed criminal charges against Lewandowski. He was sentenced', 'avg_logprob': -0.13}, {'start': 144.8, 'end': 149.84, 'text': ' to 18 months in prison and had to pay a $95,000 fine, but luckily got a presidential pardon from', 'avg_logprob': -0.13}, {'start': 149.84, 'end': 153.84, 'text': " Donald Trump. Now, normally, I like to tell kids that crime doesn't pay, but in his case,", 'avg_logprob': -0.13}, {'start': 153.84, 'end': 158.24, 'text': " it was probably worth it. A good saying in life is it's not what you know, but who you know.", 'avg_logprob': -0.13}, {'start': 158.24, 'end': 162.96, 'text': ' And Raj Rajartanam is a good example of this. He was a hedge fund manager with deep connections', 'avg_logprob': -0.13}, {'start': 162.96, 'end': 168.56, 'text': ' to big tech. Companies like Intel, IBM, AMD, and many others. He too became one of the richest men', 'avg_logprob': -0.11}, {'start': 168.56, 'end': 172.96, 'text': ' in the world. It thanks to his brilliant trading strategy that relied on confidential information from', 'avg_logprob': -0.11}, {'start': 172.96, 'end': 178.48, 'text': ' tech insiders. Unfortunately, this strategy is illegal, and he was arrested in 2009 for insider trading', 'avg_logprob': -0.11}, {'start': 178.48, 'end': 182.48, 'text': ' and sentenced to 11 years in prison. Insider trading is a great infinite money glitch,', 'avg_logprob': -0.11}, {'start': 182.48, 'end': 186.56, 'text': " but you can really only get away with it if you're in politics. My advice is to just follow the", 'avg_logprob': -0.11}, {'start': 186.56, 'end': 191.52, 'text': ' trades of Congress and do as they do. That is financial advice, by the way, although I am not qualified', 'avg_logprob': -0.11}, {'start': 191.52, 'end': 195.12, 'text': " to give it. I'd be extremely disappointed, though, if you went to prison, without using the", 'avg_logprob': -0.08}, {'start': 195.12, 'end': 200.16, 'text': " programming skills you've learned on this channel. Max Butler, also known as Max Vision or Iceman,", 'avg_logprob': -0.08}, {'start': 200.16, 'end': 204.72, 'text': ' was a cybersecurity consultant who did penetration testing. While doing work on federal government', 'avg_logprob': -0.08}, {'start': 204.72, 'end': 209.52, 'text': ' websites, he installed a backdoor on a buying server demon, which is a set of tools for managing', 'avg_logprob': -0.08}, {'start': 209.52, 'end': 213.76, 'text': ' the phone book of the internet, the domain name system. He was eventually caught by the Air Force', 'avg_logprob': -0.08}, {'start': 213.76, 'end': 218.88, 'text': " and sentenced to 18 months in federal prison, but he didn't stop there. Undeterred, he continued to", 'avg_logprob': -0.08}, {'start': 218.88, 'end': 223.04, 'text': " develop his hacking skills and launched a website called Carter's Market, where criminals could", 'avg_logprob': -0.11}, {'start': 223.04, 'end': 228.72, 'text': ' illegally trade stolen credit card details. The website was responsible for $86 million in fraudulent', 'avg_logprob': -0.11}, {'start': 228.72, 'end': 234.16, 'text': ' purchases. In 2007, he was arrested and sentenced to 13 years in prison and ordered to pay $27', 'avg_logprob': -0.11}, {'start': 234.16, 'end': 238.56, 'text': ' million in restitution. At the time, it was the longest prison sentence ever handed down for hacking.', 'avg_logprob': -0.11}, {'start': 238.56, 'end': 243.36, 'text': " That punishment may seem harsh, but it's nothing compared to Ross Ulbrick. In 2011, he launched", 'avg_logprob': -0.11}, {'start': 243.36, 'end': 248.08, 'text': ' a website built with PHP. He was likely inspired by all the other PHP developers out there driving', 'avg_logprob': -0.11}, {'start': 248.08, 'end': 252.72, 'text': ' land bows. His website was unique, though, because it allowed anyone to trade any type of good', 'avg_logprob': -0.1}, {'start': 252.72, 'end': 258.08, 'text': ' without any type of regulation anonymously with cryptocurrency. It was a true free market that was used', 'avg_logprob': -0.1}, {'start': 258.08, 'end': 262.64, 'text': ' to facilitate all kinds of illegal activity. The website was only online for about two years,', 'avg_logprob': -0.1}, {'start': 262.64, 'end': 267.52, 'text': ' but had a sales volume of nearly 10 billion bitcoins. Back then, when Bitcoin was only a few', 'avg_logprob': -0.1}, {'start': 267.52, 'end': 273.36, 'text': " bucks, but in today's money, with Bitcoin at $69,420, Ross would easily be the richest man", 'avg_logprob': -0.1}, {'start': 273.36, 'end': 277.76, 'text': ' in the world, but unfortunately, he got caught. In the early days, he used his personal email', 'avg_logprob': -0.11}, {'start': 277.76, 'end': 282.08, 'text': ' to promote the Silk Road, which investigators used to identify him. On the website, he was known', 'avg_logprob': -0.11}, {'start': 282.08, 'end': 286.88, 'text': ' as Dread Pirate Roberts, but in 2013, was arrested at a public library in San Francisco,', 'avg_logprob': -0.11}, {'start': 286.88, 'end': 290.88, 'text': ' while logged into the Silk Road as an admin. This case was a huge embarrassment to the feds', 'avg_logprob': -0.11}, {'start': 290.88, 'end': 295.76, 'text': ' in the war on drugs, and Ross ultimately received two life sentences without the possibility of parole', 'avg_logprob': -0.11}, {'start': 295.76, 'end': 301.2, 'text': " plus 40 years. He'll die in prison for creating a PHP website. PHP haters say that's justified,", 'avg_logprob': -0.11}, {'start': 301.2, 'end': 305.28, 'text': ' but many believe a sentence is too harsh. And that gives us seven tech bros who went to prison,', 'avg_logprob': -0.14}, {'start': 305.28, 'end': 309.52, 'text': ' huge shout out to the US Department of Justice and the for-profit prison industry for making', 'avg_logprob': -0.14}, {'start': 309.52, 'end': 313.28, 'text': ' this video possible. And if you want to learn how to accept payments in your own application,', 'avg_logprob': -0.14}, {'start': 313.28, 'end': 317.6, 'text': ' check out my brand new course on Fireship.io that will teach you everything you need to know about', 'avg_logprob': -0.14}, {'start': 317.6, 'end': 322.0, 'text': ' implementing payments into a software as a service product. This has been the code report. Thanks', 'avg_logprob': -0.14}, {'start': 322.0, 'end': 332.0, 'text': ' for watching, and I will see you in the next one.', 'avg_logprob': -0.38}]

metadata_dicts = [
    {
        "start": 0.43,
        "end": 4.65,
        "text": " Let's assume your monthly income were to somehow double.",
        "avg_logprob": -0.18,
    },
    {"start": 4.65, "end": 5.95, "text": " Congratulations.", "avg_logprob": -0.18},
    {
        "start": 5.95,
        "end": 10.15,
        "text": " You can now, for the most part, afford to buy two times more stuff.",
        "avg_logprob": -0.18,
    },
    {
        "start": 10.15,
        "end": 13.91,
        "text": " But what if the monthly income of everyone else were to also double?",
        "avg_logprob": -0.18,
    },
    {
        "start": 13.91,
        "end": 18.59,
        "text": " Well, in that case, you'd no longer be able to buy two times more stuff, because since",
        "avg_logprob": -0.18,
    },
    {
        "start": 18.59,
        "end": 23.79,
        "text": " everyone else also earns two times more, there would be two times more money chasing roughly",
        "avg_logprob": -0.18,
    },
    {
        "start": 23.79,
        "end": 26.07,
        "text": " the same number of goods.",
        "avg_logprob": -0.18,
    },
    {
        "start": 26.07,
        "end": 28.11,
        "text": " Let's take things one step further.",
        "avg_logprob": -0.18,
    },
    {
        "start": 28.11,
        "end": 32.03,
        "text": " What if your income doubles, but the income of everyone else triples?",
        "avg_logprob": -0.18,
    },
    {
        "start": 32.03,
        "end": 35.03,
        "text": " In that case, you'd actually become poorer.",
        "avg_logprob": -0.18,
    },
    {"start": 35.03, "end": 36.03, "text": " Why?", "avg_logprob": -0.18},
    {
        "start": 36.03,
        "end": 40.63,
        "text": " Because making two times more money is not enough to keep up with everyone else, who now",
        "avg_logprob": -0.18,
    },
    {
        "start": 40.63,
        "end": 43.03,
        "text": " makes three times more.",
        "avg_logprob": -0.18,
    },
    {
        "start": 43.03,
        "end": 48.23,
        "text": " If there's an overall increase in the price of goods and services of X% this year, you",
        "avg_logprob": -0.18,
    },
    {
        "start": 48.23,
        "end": 54.59,
        "text": " have to earn at least X% more than last year to avoid becoming poorer in real terms.",
        "avg_logprob": -0.18,
    },
    {
        "start": 54.59,
        "end": 58.35,
        "text": " History makes the effects of inflation crystal clear.",
        "avg_logprob": -0.24,
    },
    {
        "start": 58.35,
        "end": 64.95,
        "text": " Today, each dollar buys you approximately 39 times less potatoes than 100 years ago,",
        "avg_logprob": -0.24,
    },
    {
        "start": 64.95,
        "end": 69.47,
        "text": " or 20 times less coffee, 24 times less bread, and so on.",
        "avg_logprob": -0.24,
    },
]



chunker = TextChunker()
metadata_chunks = chunker.chunk_texts(metadata_dicts, video=None)
print(metadata_chunks)